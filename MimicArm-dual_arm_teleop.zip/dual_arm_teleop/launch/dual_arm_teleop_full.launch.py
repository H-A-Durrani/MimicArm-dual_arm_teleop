"""
dual_arm_teleop_full.launch.py
Full launch: robot_state_publisher + MoveIt 2 + motion_planner + teleop + RViz
"""

import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import (
    DeclareLaunchArgument,
    IncludeLaunchDescription,
    TimerAction,
)
from launch.conditions import IfCondition
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import (
    LaunchConfiguration,
    PathJoinSubstitution,
    Command,
)
from launch_ros.actions import Node
from launch_ros.substitutions import FindPackageShare


def generate_launch_description():
    pkg = get_package_share_directory('dual_arm_teleop')

    # ── Arguments ─────────────────────────────────────────────────────────
    declare_camera = DeclareLaunchArgument(
        'camera_index', default_value='0',
        description='OpenCV camera index')
    declare_rate = DeclareLaunchArgument(
        'publish_rate', default_value='30.0',
        description='Node publish rate in Hz')
    declare_ema = DeclareLaunchArgument(
        'ema_alpha', default_value='0.25',
        description='EMA smoothing factor (0.1=smooth, 0.5=responsive)')
    declare_preview = DeclareLaunchArgument(
        'show_preview', default_value='true',
        description='Show OpenCV camera preview window')
    declare_use_moveit = DeclareLaunchArgument(
        'use_moveit', default_value='true',
        description='Use MoveIt 2 for motion planning (false = analytic IK only)')
    declare_rviz = DeclareLaunchArgument(
        'launch_rviz', default_value='true',
        description='Launch RViz')

    # ── Robot description (URDF via xacro) ────────────────────────────────
    urdf_path = os.path.join(pkg, 'urdf', 'dual_arm_robot.urdf.xacro')
    robot_description_content = Command(['xacro ', urdf_path])

    robot_state_publisher = Node(
        package='robot_state_publisher',
        executable='robot_state_publisher',
        name='robot_state_publisher',
        output='screen',
        parameters=[{
            'robot_description': robot_description_content,
            'use_sim_time': False,
        }],
    )

    # ── Teleop node ────────────────────────────────────────────────────────
    teleop_node = Node(
        package='dual_arm_teleop',
        executable='teleop_node.py',
        name='teleop_node',
        output='screen',
        parameters=[{
            'camera_index':  LaunchConfiguration('camera_index'),
            'publish_rate':  LaunchConfiguration('publish_rate'),
            'ema_alpha':     LaunchConfiguration('ema_alpha'),
            'show_preview':  LaunchConfiguration('show_preview'),
        }],
    )

    # ── Motion planner node (with MoveIt) ─────────────────────────────────
    motion_planner_node = Node(
        package='dual_arm_teleop',
        executable='motion_planner_node.py',
        name='motion_planner_node',
        output='screen',
        parameters=[{
            'publish_rate': LaunchConfiguration('publish_rate'),
            'use_moveit':   LaunchConfiguration('use_moveit'),
        }],
    )

    # ── RViz ──────────────────────────────────────────────────────────────
    rviz_config = os.path.join(pkg, 'rviz', 'dual_arm_teleop.rviz')
    rviz_node = Node(
        package='rviz2',
        executable='rviz2',
        name='rviz2',
        arguments=['-d', rviz_config],
        condition=IfCondition(LaunchConfiguration('launch_rviz')),
        output='screen',
    )

    return LaunchDescription([
        declare_camera,
        declare_rate,
        declare_ema,
        declare_preview,
        declare_use_moveit,
        declare_rviz,
        robot_state_publisher,
        # Small delay so RSP is up before the planner tries to query it
        TimerAction(period=1.0, actions=[motion_planner_node]),
        TimerAction(period=1.5, actions=[teleop_node]),
        TimerAction(period=2.0, actions=[rviz_node]),
    ])
