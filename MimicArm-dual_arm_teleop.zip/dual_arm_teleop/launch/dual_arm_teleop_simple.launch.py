"""
dual_arm_teleop_simple.launch.py
Minimal launch: robot_state_publisher + analytic IK joint publisher + teleop + RViz
Does NOT require MoveIt 2 — ideal for first run / demo on bare systems.
"""

import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, TimerAction
from launch.conditions import IfCondition
from launch.substitutions import LaunchConfiguration, Command
from launch_ros.actions import Node


def generate_launch_description():
    pkg = get_package_share_directory('dual_arm_teleop')

    declare_camera  = DeclareLaunchArgument('camera_index',  default_value='0')
    declare_rate    = DeclareLaunchArgument('publish_rate',  default_value='30.0')
    declare_ema     = DeclareLaunchArgument('ema_alpha',     default_value='0.25')
    declare_preview = DeclareLaunchArgument('show_preview',  default_value='true')
    declare_rviz    = DeclareLaunchArgument('launch_rviz',   default_value='true')

    urdf_path = os.path.join(pkg, 'urdf', 'dual_arm_robot.urdf.xacro')

    robot_state_publisher = Node(
        package='robot_state_publisher',
        executable='robot_state_publisher',
        name='robot_state_publisher',
        parameters=[{
            'robot_description': Command(['xacro ', urdf_path]),
            'use_sim_time': False,
        }],
        output='screen',
    )

    # Analytic IK joint state publisher (no MoveIt)
    joint_pub_node = Node(
        package='dual_arm_teleop',
        executable='joint_state_publisher_node.py',
        name='joint_state_publisher_node',
        parameters=[{'publish_rate': LaunchConfiguration('publish_rate')}],
        output='screen',
    )

    teleop_node = Node(
        package='dual_arm_teleop',
        executable='teleop_node.py',
        name='teleop_node',
        parameters=[{
            'camera_index': LaunchConfiguration('camera_index'),
            'publish_rate': LaunchConfiguration('publish_rate'),
            'ema_alpha':    LaunchConfiguration('ema_alpha'),
            'show_preview': LaunchConfiguration('show_preview'),
        }],
        output='screen',
    )

    rviz_config = os.path.join(pkg, 'rviz', 'dual_arm_teleop.rviz')
    rviz_node = Node(
        package='rviz2',
        executable='rviz2',
        name='rviz2',
        arguments=['-d', rviz_config],
        condition=IfCondition(LaunchConfiguration('launch_rviz')),
        output='screen',
    )

    return LaunchDescription([
        declare_camera, declare_rate, declare_ema, declare_preview, declare_rviz,
        robot_state_publisher,
        TimerAction(period=0.8, actions=[joint_pub_node]),
        TimerAction(period=1.2, actions=[teleop_node]),
        TimerAction(period=1.5, actions=[rviz_node]),
    ])
