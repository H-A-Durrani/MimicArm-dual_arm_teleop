# Dual Arm Teleoperation — ROS 2 Humble


```bash
# 1. Install Python dependencies
pip3 install mediapipe opencv-python numpy

# 2. Clone / copy this repo into your ROS 2 workspace
mkdir -p ~/ros2_ws/src && cd ~/ros2_ws/src
# (copy or symlink dual_arm_teleop here)

# 3. Build
cd ~/ros2_ws
colcon build --symlink-install
source install/setup.bash

# 4. Launch (RViz + analytic IK, no MoveIt required)
ros2 launch dual_arm_teleop dual_arm_teleop_simple.launch.py
```

Show both hands to the camera. The robot arms in RViz follow immediately.

---

## System Overview

```
Camera → MediaPipe Hands → teleop_node → /ee_target_pose
                                       → /gripper_close
                                              ↓
                              motion_planner_node (MoveIt IK)
                              OR joint_state_publisher_node (analytic IK)
                                              ↓
                                       /joint_states
                                              ↓
                              robot_state_publisher → RViz
```

### Published Topics

| Topic | Type | Description |
|-------|------|-------------|
| `/left_arm/ee_target_pose`  | `geometry_msgs/PoseStamped` | Left EE target |
| `/right_arm/ee_target_pose` | `geometry_msgs/PoseStamped` | Right EE target |
| `/left_arm/gripper_close`   | `std_msgs/Bool` | Left gripper state |
| `/right_arm/gripper_close`  | `std_msgs/Bool` | Right gripper state |
| `/joint_states`             | `sensor_msgs/JointState` | All joint angles |

---

## Prerequisites

### ROS 2 Humble (required)
### Python packages

pip3 install mediapipe opencv-python numpy

### ROS 2 packages

```bash
sudo apt install \
  ros-humble-robot-state-publisher \
  ros-humble-xacro \
  ros-humble-rviz2 \
  ros-humble-joint-state-publisher \
  ros-humble-tf2-ros \
  ros-humble-tf2-geometry-msgs
```

### MoveIt 2 (optional — only needed for `dual_arm_teleop_full.launch.py`)

```bash
sudo apt install ros-humble-moveit
# For moveit_py bindings:
pip3 install moveit
```

---

## Building

```bash
cd ~/ros2_ws
rosdep install --from-paths src --ignore-src -r -y
colcon build --symlink-install --cmake-args -DCMAKE_BUILD_TYPE=Release
source install/setup.bash
```

---

## Running

```bash
ros2 launch dual_arm_teleop dual_arm_teleop_simple.launch.py \
```


## Gesture Controls

| Hand gesture | Action |
|-------------|--------|
| Move right hand left/right | Right arm moves laterally (Y axis) |
| Move right hand up/down | Right arm moves vertically (Z axis) |
| Rotate right wrist | Right arm EE rotates around Z (yaw) |
| Pinch right index+thumb | Close right gripper |
| Release right pinch | Open right gripper |
| Same gestures, left hand | Left arm + left gripper |

