#!/usr/bin/env python3
"""
Joint State Publisher Node — dual_arm_teleop
=============================================
Lightweight standalone node that:
  1. Subscribes to /left_arm/ee_target_pose and /right_arm/ee_target_pose
  2. Runs analytic IK internally (no MoveIt dependency)
  3. Publishes /joint_states for RViz + robot_state_publisher

Use this node when running in RViz-only mode without a full MoveIt stack.
"""

import math
import threading
from typing import Dict, Optional, List

import rclpy
from rclpy.node import Node
from rclpy.qos import QoSProfile, ReliabilityPolicy, HistoryPolicy

from geometry_msgs.msg import PoseStamped
from sensor_msgs.msg import JointState
from std_msgs.msg import Bool, Header

# Re-use IK from motion_planner_node
import sys, os
sys.path.insert(0, os.path.dirname(__file__))
from motion_planner_node import (
    analytic_ik,
    LEFT_ARM_JOINTS, RIGHT_ARM_JOINTS,
    LEFT_GRIPPER_JOINTS, RIGHT_GRIPPER_JOINTS,
    ALL_JOINTS, HOME_LEFT, HOME_RIGHT,
    GRIPPER_OPEN_POS, GRIPPER_CLOSED_POS,
)


class JointStatePublisherNode(Node):

    def __init__(self):
        super().__init__('joint_state_publisher_node')

        self.declare_parameter('publish_rate', 30.0)
        pub_rate = self.get_parameter('publish_rate').value

        self._positions: Dict[str, float] = {}
        self._lock = threading.Lock()
        self._init_home()

        qos = QoSProfile(
            reliability=ReliabilityPolicy.BEST_EFFORT,
            history=HistoryPolicy.KEEP_LAST,
            depth=1,
        )

        self.create_subscription(
            PoseStamped, '/left_arm/ee_target_pose',
            lambda m: self._ee_cb(m, 'left'), qos)
        self.create_subscription(
            PoseStamped, '/right_arm/ee_target_pose',
            lambda m: self._ee_cb(m, 'right'), qos)
        self.create_subscription(
            Bool, '/left_arm/gripper_close',
            lambda m: self._grip_cb(m, 'left'), qos)
        self.create_subscription(
            Bool, '/right_arm/gripper_close',
            lambda m: self._grip_cb(m, 'right'), qos)

        self.pub = self.create_publisher(JointState, '/joint_states', 10)
        self.timer = self.create_timer(1.0 / pub_rate, self._publish)

        self.get_logger().info('Joint state publisher node ready (analytic IK).')

    def _init_home(self):
        for n, v in zip(LEFT_ARM_JOINTS,  HOME_LEFT):
            self._positions[n] = v
        for n, v in zip(RIGHT_ARM_JOINTS, HOME_RIGHT):
            self._positions[n] = v
        for n in LEFT_GRIPPER_JOINTS + RIGHT_GRIPPER_JOINTS:
            self._positions[n] = GRIPPER_OPEN_POS

    def _ee_cb(self, msg: PoseStamped, side: str):
        px = msg.pose.position.x
        py = msg.pose.position.y
        pz = msg.pose.position.z
        qz = msg.pose.orientation.z
        qw = msg.pose.orientation.w
        yaw = 2.0 * math.atan2(qz, qw)
        joints = analytic_ik(px, py, pz, yaw, side)
        if joints is None:
            return
        names = LEFT_ARM_JOINTS if side == 'left' else RIGHT_ARM_JOINTS
        with self._lock:
            for n, v in zip(names, joints):
                self._positions[n] = v

    def _grip_cb(self, msg: Bool, side: str):
        pos = GRIPPER_CLOSED_POS if msg.data else GRIPPER_OPEN_POS
        names = LEFT_GRIPPER_JOINTS if side == 'left' else RIGHT_GRIPPER_JOINTS
        with self._lock:
            for n in names:
                self._positions[n] = pos

    def _publish(self):
        with self._lock:
            positions = dict(self._positions)
        msg = JointState()
        msg.header = Header(stamp=self.get_clock().now().to_msg(), frame_id='')
        for name in ALL_JOINTS:
            msg.name.append(name)
            msg.position.append(positions.get(name, 0.0))
            msg.velocity.append(0.0)
            msg.effort.append(0.0)
        self.pub.publish(msg)


def main(args=None):
    rclpy.init(args=args)
    node = JointStatePublisherNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
