#!/usr/bin/env python3
"""
Motion Planner Node — dual_arm_teleop
=======================================
Subscribes to /left_arm/ee_target_pose and /right_arm/ee_target_pose
(geometry_msgs/PoseStamped) and uses MoveIt 2 to compute collision-free
joint trajectories for each arm.

Safety design:
  - Self-collision avoidance delegated to MoveIt 2 planning scene
  - Joint velocity limits respected via trajectory time-parametrisation
  - If planning fails the arm holds its current configuration (fail-safe hold)
  - Maximum Cartesian displacement per cycle is bounded (watchdog check)
  - Gripper commands mapped to prismatic joint positions

For the real-robot scenario the /joint_states publisher runs at the same
frequency so the robot can track it directly.
"""

import math
import threading
from typing import Dict, List, Optional

import numpy as np

import rclpy
from rclpy.node import Node
from rclpy.qos import QoSProfile, ReliabilityPolicy, HistoryPolicy

from geometry_msgs.msg import PoseStamped
from sensor_msgs.msg import JointState
from std_msgs.msg import Bool, Header
from trajectory_msgs.msg import JointTrajectory, JointTrajectoryPoint
from builtin_interfaces.msg import Duration

# MoveIt 2 Python bindings (moveit_py or moveit_commander fallback)
try:
    from moveit.planning import MoveItPy                   # moveit_py (Humble+)
    from moveit.core.robot_state import RobotState
    MOVEIT_PY = True
except ImportError:
    MOVEIT_PY = False
    try:
        import moveit_commander                             # legacy fallback
        MOVEIT_COMMANDER = True
    except ImportError:
        MOVEIT_COMMANDER = False


# ─────────────────────────────────────────────────────────────────────────────
# Joint name maps
# ─────────────────────────────────────────────────────────────────────────────

LEFT_ARM_JOINTS = [
    'left_shoulder_pan',
    'left_shoulder_lift',
    'left_elbow',
    'left_wrist1_joint',
    'left_wrist2_joint',
    'left_wrist3_joint',
]
RIGHT_ARM_JOINTS = [
    'right_shoulder_pan',
    'right_shoulder_lift',
    'right_elbow',
    'right_wrist1_joint',
    'right_wrist2_joint',
    'right_wrist3_joint',
]
LEFT_GRIPPER_JOINTS  = ['left_finger_left_joint',  'left_finger_right_joint']
RIGHT_GRIPPER_JOINTS = ['right_finger_left_joint', 'right_finger_right_joint']
GRIPPER_OPEN_POS   = 0.035   # metres
GRIPPER_CLOSED_POS = 0.005   # metres

ALL_JOINTS = (
    LEFT_ARM_JOINTS + LEFT_GRIPPER_JOINTS +
    RIGHT_ARM_JOINTS + RIGHT_GRIPPER_JOINTS
)

# Home configuration (arms raised slightly, elbows bent)
HOME_LEFT  = [0.0, -1.2, 1.4, -0.2, 0.0, 0.0]
HOME_RIGHT = [0.0, -1.2, 1.4, -0.2, 0.0, 0.0]


# ─────────────────────────────────────────────────────────────────────────────
# Analytic IK — fallback when MoveIt is unavailable
# Implements a simplified geometric IK for the 6DOF arm.
# Joints: shoulder_pan, shoulder_lift, elbow, wrist1, wrist2, wrist3
# Link lengths must match the URDF.
# ─────────────────────────────────────────────────────────────────────────────

L1 = 0.30   # upper arm
L2 = 0.27   # forearm
L3 = 0.20   # wrist1
L4 = 0.12   # wrist2 + tool

# Shoulder mount heights (Z from base) — left and right identical
SHOULDER_HEIGHT = 0.05

def analytic_ik(target_x: float, target_y: float, target_z: float,
                target_yaw: float, side: str = 'left') -> Optional[List[float]]:
    """
    Simplified geometric IK — 2D movement in XZ plane + pan rotation.
    Only joints 1–4 are actively solved; wrist joints set from target_yaw.

    Returns list of 6 joint angles or None if unreachable.
    """
    # Mount offset
    mount_x = 0.25 if side == 'left' else -0.25

    # Vector from shoulder to target
    dx = target_x - mount_x
    dz = target_z - SHOULDER_HEIGHT

    # Shoulder pan: angle to target in XY plane
    pan = math.atan2(target_y, dx)

    # Planar distance from shoulder to target (ignoring y after pan)
    r = math.hypot(dx, target_y)
    reach_2d = math.hypot(r, dz)

    max_reach = L1 + L2 + L3
    if reach_2d > max_reach * 0.98:
        reach_2d = max_reach * 0.98   # clamp to reachable sphere

    # Elbow angle via cosine rule for (L1, L2) reaching reach_2d
    cos_elbow = (L1**2 + L2**2 - reach_2d**2) / (2 * L1 * L2)
    cos_elbow = max(-1.0, min(1.0, cos_elbow))
    elbow = math.pi - math.acos(cos_elbow)   # elbow-up solution

    # Shoulder lift
    alpha = math.atan2(dz, r)
    cos_beta = (L1**2 + reach_2d**2 - L2**2) / (2 * L1 * reach_2d)
    cos_beta = max(-1.0, min(1.0, cos_beta))
    beta     = math.acos(cos_beta)
    shoulder_lift = -(alpha + beta)

    # Wrist joints: keep EE pointing forward + apply yaw
    wrist1 = -(shoulder_lift + elbow)   # keep EE roughly level
    wrist2 = 0.0
    wrist3 = target_yaw

    joints = [pan, shoulder_lift, elbow, wrist1, wrist2, wrist3]

    # Joint limit check (rough)
    limits = [
        (-math.pi, math.pi),
        (-math.pi, 0.5),
        (-math.pi, math.pi),
        (-math.pi, math.pi),
        (-math.pi, math.pi),
        (-math.pi, math.pi),
    ]
    for j, (lo, hi) in zip(joints, limits):
        if not (lo <= j <= hi):
            return None

    return joints


# ─────────────────────────────────────────────────────────────────────────────
# Motion Planner Node
# ─────────────────────────────────────────────────────────────────────────────

class MotionPlannerNode(Node):

    def __init__(self):
        super().__init__('motion_planner_node')

        # ── Parameters ──────────────────────────────────────────────────────
        self.declare_parameter('publish_rate', 30.0)
        self.declare_parameter('use_moveit', True)
        self.declare_parameter('planning_time', 0.05)    # seconds per plan
        self.declare_parameter('max_velocity_scaling', 0.4)
        self.declare_parameter('max_accel_scaling', 0.3)

        self.pub_rate      = self.get_parameter('publish_rate').value
        self.use_moveit    = self.get_parameter('use_moveit').value
        self.planning_time = self.get_parameter('planning_time').value

        # ── MoveIt 2 setup ───────────────────────────────────────────────────
        self._moveit_ready = False
        if self.use_moveit and MOVEIT_PY:
            try:
                self.robot = MoveItPy(node_name='motion_planner_moveit')
                self.left_planner  = self.robot.get_planning_component('left_arm')
                self.right_planner = self.robot.get_planning_component('right_arm')
                self._moveit_ready = True
                self.get_logger().info('MoveIt 2 (moveit_py) ready')
            except Exception as e:
                self.get_logger().warn(f'MoveIt init failed: {e}. Using analytic IK fallback.')
        elif self.use_moveit and MOVEIT_COMMANDER:
            try:
                moveit_commander.roscpp_initialize([])
                self.robot_cmd = moveit_commander.RobotCommander()
                self.left_group  = moveit_commander.MoveGroupCommander('left_arm')
                self.right_group = moveit_commander.MoveGroupCommander('right_arm')
                self.left_group.set_planning_time(self.planning_time)
                self.right_group.set_planning_time(self.planning_time)
                self._moveit_ready = True
                self._moveit_type  = 'commander'
                self.get_logger().info('MoveIt 2 (moveit_commander) ready')
            except Exception as e:
                self.get_logger().warn(f'MoveIt commander init failed: {e}. Analytic IK.')
        else:
            self.get_logger().warn('MoveIt unavailable — using analytic IK')

        # ── Current joint state ──────────────────────────────────────────────
        self._joint_positions: Dict[str, float] = {}
        self._init_home()

        # ── Gripper state ────────────────────────────────────────────────────
        self._left_gripper_closed  = False
        self._right_gripper_closed = False
        self._lock = threading.Lock()

        # ── QoS ─────────────────────────────────────────────────────────────
        qos_sub = QoSProfile(
            reliability=ReliabilityPolicy.BEST_EFFORT,
            history=HistoryPolicy.KEEP_LAST,
            depth=1,
        )

        # ── Subscriptions ────────────────────────────────────────────────────
        self.create_subscription(
            PoseStamped, '/left_arm/ee_target_pose',
            lambda m: self._ee_callback(m, 'left'), qos_sub)
        self.create_subscription(
            PoseStamped, '/right_arm/ee_target_pose',
            lambda m: self._ee_callback(m, 'right'), qos_sub)
        self.create_subscription(
            Bool, '/left_arm/gripper_close',
            lambda m: self._grip_callback(m, 'left'), qos_sub)
        self.create_subscription(
            Bool, '/right_arm/gripper_close',
            lambda m: self._grip_callback(m, 'right'), qos_sub)

        # ── Publishers ───────────────────────────────────────────────────────
        self.pub_joint_state = self.create_publisher(JointState, '/joint_states', 10)
        self.pub_joint_traj  = self.create_publisher(
            JointTrajectory, '/arm_controller/joint_trajectory', 10)

        # ── Timer: publish joint states at fixed rate ────────────────────────
        self.timer = self.create_timer(1.0 / self.pub_rate, self._publish_joint_states)

        self.get_logger().info('Motion planner node ready.')

    def _init_home(self):
        for name, val in zip(LEFT_ARM_JOINTS,  HOME_LEFT):
            self._joint_positions[name] = val
        for name, val in zip(RIGHT_ARM_JOINTS, HOME_RIGHT):
            self._joint_positions[name] = val
        for name in LEFT_GRIPPER_JOINTS + RIGHT_GRIPPER_JOINTS:
            self._joint_positions[name] = GRIPPER_OPEN_POS

    # ─────────────────────────────────────────────────────────────────────────
    # EE target callback
    # ─────────────────────────────────────────────────────────────────────────

    def _ee_callback(self, msg: PoseStamped, side: str):
        px = msg.pose.position.x
        py = msg.pose.position.y
        pz = msg.pose.position.z

        # Extract yaw from quaternion
        qz = msg.pose.orientation.z
        qw = msg.pose.orientation.w
        yaw = 2.0 * math.atan2(qz, qw)

        joints = None

        if self._moveit_ready:
            joints = self._moveit_plan(side, msg)

        if joints is None:
            # Analytic IK fallback
            joints = analytic_ik(px, py, pz, yaw, side)

        if joints is None:
            self.get_logger().warn(
                f'IK failed for {side} arm target ({px:.2f}, {py:.2f}, {pz:.2f})',
                throttle_duration_sec=2.0,
            )
            return  # Hold current configuration

        joint_names = LEFT_ARM_JOINTS if side == 'left' else RIGHT_ARM_JOINTS
        with self._lock:
            for name, val in zip(joint_names, joints):
                self._joint_positions[name] = val

    def _grip_callback(self, msg: Bool, side: str):
        pos = GRIPPER_CLOSED_POS if msg.data else GRIPPER_OPEN_POS
        names = LEFT_GRIPPER_JOINTS if side == 'left' else RIGHT_GRIPPER_JOINTS
        with self._lock:
            for name in names:
                self._joint_positions[name] = pos

    # ─────────────────────────────────────────────────────────────────────────
    # MoveIt 2 planning (moveit_py)
    # ─────────────────────────────────────────────────────────────────────────

    def _moveit_plan(self, side: str, pose_msg: PoseStamped) -> Optional[List[float]]:
        """
        Request a Cartesian pose plan from MoveIt 2.
        Returns list of 6 joint angles at the goal, or None on failure.
        """
        try:
            if MOVEIT_PY:
                planner = self.left_planner if side == 'left' else self.right_planner
                planner.set_start_state_to_current_state()
                planner.set_goal_state(pose_stamped_msg=pose_msg,
                                       pose_link=f'{side}_ee_link')
                plan_result = planner.plan()
                if plan_result:
                    # Extract final joint values from trajectory
                    traj = plan_result.trajectory
                    last_pt = traj.joint_trajectory.points[-1]
                    return list(last_pt.positions)
            elif hasattr(self, 'left_group'):
                group = self.left_group if side == 'left' else self.right_group
                group.set_pose_target(pose_msg.pose)
                plan = group.plan()
                if plan[0]:
                    last_pt = plan[1].joint_trajectory.points[-1]
                    return list(last_pt.positions)
        except Exception as e:
            self.get_logger().debug(f'MoveIt plan error ({side}): {e}')
        return None

    # ─────────────────────────────────────────────────────────────────────────
    # Joint state publisher
    # ─────────────────────────────────────────────────────────────────────────

    def _publish_joint_states(self):
        with self._lock:
            positions = dict(self._joint_positions)

        msg = JointState()
        msg.header = Header(stamp=self.get_clock().now().to_msg(), frame_id='')
        for name in ALL_JOINTS:
            msg.name.append(name)
            msg.position.append(positions.get(name, 0.0))
            msg.velocity.append(0.0)
            msg.effort.append(0.0)

        self.pub_joint_state.publish(msg)


# ─────────────────────────────────────────────────────────────────────────────

def main(args=None):
    rclpy.init(args=args)
    node = MotionPlannerNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
