#!/usr/bin/env python3
"""
Teleoperation Node — dual_arm_teleop
=====================================
Captures operator hand motion via camera + MediaPipe Hands, maps 2D hand
positions (+ wrist rotation) to end-effector target poses for both arms,
and publishes gripper open/close commands.

Design decisions to handle real-world noise:
  - Exponential Moving Average (EMA) on raw landmark coords
  - Velocity clamping: prevents unrealistically fast EE jumps
  - Deadband: small motions below threshold are ignored
  - One-shot human: only the FIRST detected person is tracked; if two
    people are in frame the secondary person's hands are ignored.
  - Workspace bounds: EE targets are clamped to a safe reachable cube.

2D Movement + 1D Rotation mapping:
  - EE moves in the XY plane of the robot's workspace
  - Hand X → EE Y (lateral)
  - Hand Y → EE Z (height)
  - Wrist rotation (thumb angle) → EE rotation around Z (yaw)
  - Gripper: index–thumb pinch distance below threshold → close
"""

import math
import time
import threading
from collections import deque
from typing import Optional, Tuple

import cv2
import mediapipe as mp
import numpy as np

import rclpy
from rclpy.node import Node
from rclpy.qos import QoSProfile, ReliabilityPolicy, HistoryPolicy

from geometry_msgs.msg import PoseStamped, Pose
from std_msgs.msg import Bool, Float32, Header
from sensor_msgs.msg import Image

# Optional: publish debug overlay image
try:
    from cv_bridge import CvBridge
    CV_BRIDGE_AVAILABLE = True
except ImportError:
    CV_BRIDGE_AVAILABLE = False


# ─────────────────────────────────────────────────────────────────────────────
# Constants & tuning parameters
# ─────────────────────────────────────────────────────────────────────────────

# MediaPipe landmark indices
WRIST        = 0
THUMB_CMC    = 1
THUMB_MCP    = 2
THUMB_IP     = 3
THUMB_TIP    = 4
INDEX_MCP    = 5
INDEX_TIP    = 8
MIDDLE_MCP   = 9
MIDDLE_TIP   = 12
RING_MCP     = 13
PINKY_MCP    = 17

# Workspace limits in robot base frame (metres)
WS_X_FIXED   = 0.45   # EE always kept at this forward reach
WS_Y_MIN     = -0.50
WS_Y_MAX     =  0.50
WS_Z_MIN     =  0.10
WS_Z_MAX     =  0.80
WS_YAW_RANGE = math.pi  # ±90° yaw from centre

# Noise filtering
EMA_ALPHA    = 0.25   # smaller = smoother but laggier (0.1–0.4 typical)
VEL_LIMIT    = 0.008  # max EE displacement per frame (metres)
DEADBAND     = 0.003  # ignore movements smaller than this

# Gripper
PINCH_CLOSE_THRESH = 0.06   # normalised image distance for "closed"
PINCH_OPEN_THRESH  = 0.10   # hysteresis: must open past this to re-open

# Workspace normalisation: map hand position [0,1] → robot workspace
def hand_x_to_ee_y(hx: float) -> float:
    """Normalised hand X [0,1] → EE Y in robot frame."""
    return WS_Y_MIN + hx * (WS_Y_MAX - WS_Y_MIN)

def hand_y_to_ee_z(hy: float) -> float:
    """Normalised hand Y [0,1] → EE Z in robot frame (inverted: hand up = EE up)."""
    return WS_Z_MAX - hy * (WS_Z_MAX - WS_Z_MIN)


# ─────────────────────────────────────────────────────────────────────────────
# EMA Filter
# ─────────────────────────────────────────────────────────────────────────────

class EMAFilter:
    """Per-channel Exponential Moving Average filter with velocity clamping."""

    def __init__(self, alpha: float, vel_limit: float, deadband: float,
                 initial_value: Optional[np.ndarray] = None):
        self.alpha = alpha
        self.vel_limit = vel_limit
        self.deadband = deadband
        self._value: Optional[np.ndarray] = initial_value
        self._initialized = initial_value is not None

    def update(self, raw: np.ndarray) -> np.ndarray:
        if not self._initialized:
            self._value = raw.copy()
            self._initialized = True
            return self._value.copy()

        delta = raw - self._value

        # Deadband: suppress micro-jitter
        delta = np.where(np.abs(delta) < self.deadband, 0.0, delta)

        # Velocity clamp: cap maximum per-frame movement
        magnitude = np.linalg.norm(delta)
        if magnitude > self.vel_limit:
            delta = delta * (self.vel_limit / magnitude)

        # EMA
        self._value = self._value + self.alpha * delta
        return self._value.copy()

    @property
    def value(self) -> Optional[np.ndarray]:
        return self._value.copy() if self._initialized else None

    def reset(self, value: np.ndarray):
        self._value = value.copy()
        self._initialized = True


# ─────────────────────────────────────────────────────────────────────────────
# Gripper state machine (hysteresis)
# ─────────────────────────────────────────────────────────────────────────────

class GripperController:
    def __init__(self, close_thresh: float, open_thresh: float):
        self.close_thresh = close_thresh
        self.open_thresh = open_thresh
        self._closed = False

    def update(self, pinch_distance: float) -> bool:
        """Returns True if gripper should be closed."""
        if not self._closed and pinch_distance < self.close_thresh:
            self._closed = True
        elif self._closed and pinch_distance > self.open_thresh:
            self._closed = False
        return self._closed

    @property
    def is_closed(self) -> bool:
        return self._closed


# ─────────────────────────────────────────────────────────────────────────────
# Teleoperation Node
# ─────────────────────────────────────────────────────────────────────────────

class TeleopNode(Node):

    def __init__(self):
        super().__init__('teleop_node')

        # ── Parameters ──────────────────────────────────────────────────────
        self.declare_parameter('camera_index', 0)
        self.declare_parameter('publish_rate', 30.0)
        self.declare_parameter('ema_alpha', EMA_ALPHA)
        self.declare_parameter('vel_limit', VEL_LIMIT)
        self.declare_parameter('deadband', DEADBAND)
        self.declare_parameter('show_preview', True)
        self.declare_parameter('publish_debug_image', False)
        self.declare_parameter('frame_id', 'base_link')
        self.declare_parameter('mirror_mode', True)  # mirror so it feels natural

        cam_idx    = self.get_parameter('camera_index').value
        pub_rate   = self.get_parameter('publish_rate').value
        alpha      = self.get_parameter('ema_alpha').value
        vel_lim    = self.get_parameter('vel_limit').value
        deadband   = self.get_parameter('deadband').value
        self.show_preview    = self.get_parameter('show_preview').value
        self.pub_debug_image = self.get_parameter('publish_debug_image').value
        self.frame_id        = self.get_parameter('frame_id').value
        self.mirror_mode     = self.get_parameter('mirror_mode').value

        # ── QoS ─────────────────────────────────────────────────────────────
        qos = QoSProfile(
            reliability=ReliabilityPolicy.BEST_EFFORT,
            history=HistoryPolicy.KEEP_LAST,
            depth=1,
        )

        # ── Publishers ───────────────────────────────────────────────────────
        self.pub_left_ee   = self.create_publisher(PoseStamped, '/left_arm/ee_target_pose',  qos)
        self.pub_right_ee  = self.create_publisher(PoseStamped, '/right_arm/ee_target_pose', qos)
        self.pub_left_grip = self.create_publisher(Bool,        '/left_arm/gripper_close',   qos)
        self.pub_right_grip= self.create_publisher(Bool,        '/right_arm/gripper_close',  qos)

        if self.pub_debug_image and CV_BRIDGE_AVAILABLE:
            self.pub_debug = self.create_publisher(Image, '/teleop/debug_image', 10)
            self.bridge = CvBridge()
        else:
            self.pub_debug = None

        # ── MediaPipe setup ──────────────────────────────────────────────────
        self.mp_hands = mp.solutions.hands
        self.mp_draw  = mp.solutions.drawing_utils
        self.mp_draw_styles = mp.solutions.drawing_styles

        self.hands = self.mp_hands.Hands(
            static_image_mode=False,
            max_num_hands=2,
            model_complexity=1,
            min_detection_confidence=0.7,
            min_tracking_confidence=0.6,
        )

        # ── Filters (one per arm/DOF) ────────────────────────────────────────
        left_init  = np.array([WS_X_FIXED, 0.15, 0.50, 0.0])   # x,y,z,yaw
        right_init = np.array([WS_X_FIXED, -0.15, 0.50, 0.0])

        self.filter_left  = EMAFilter(alpha, vel_lim, deadband, left_init)
        self.filter_right = EMAFilter(alpha, vel_lim, deadband, right_init)

        # ── Gripper state machines ───────────────────────────────────────────
        self.gripper_left  = GripperController(PINCH_CLOSE_THRESH, PINCH_OPEN_THRESH)
        self.gripper_right = GripperController(PINCH_CLOSE_THRESH, PINCH_OPEN_THRESH)

        # ── Camera ───────────────────────────────────────────────────────────
        self.cap = cv2.VideoCapture(cam_idx)
        if not self.cap.isOpened():
            self.get_logger().error(f'Cannot open camera at index {cam_idx}')
            raise RuntimeError('Camera unavailable')
        self.cap.set(cv2.CAP_PROP_FRAME_WIDTH,  640)
        self.cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
        self.cap.set(cv2.CAP_PROP_FPS, 30)

        self._lock = threading.Lock()
        self._last_landmarks = {}  # side → landmarks

        # ── Timer ────────────────────────────────────────────────────────────
        period = 1.0 / pub_rate
        self.timer = self.create_timer(period, self._timer_callback)

        # ── Camera thread ────────────────────────────────────────────────────
        self._running = True
        self._cam_thread = threading.Thread(target=self._camera_loop, daemon=True)
        self._cam_thread.start()

        self.get_logger().info('Teleoperation node started. Show both hands to begin.')

    # ─────────────────────────────────────────────────────────────────────────
    # Camera capture loop (separate thread for max frame rate)
    # ─────────────────────────────────────────────────────────────────────────

    def _camera_loop(self):
        while self._running:
            ret, frame = self.cap.read()
            if not ret:
                self.get_logger().warn('Camera frame drop', throttle_duration_sec=5.0)
                time.sleep(0.01)
                continue

            if self.mirror_mode:
                frame = cv2.flip(frame, 1)

            rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            results = self.hands.process(rgb)

            landmarks_by_side = {}
            if results.multi_hand_landmarks and results.multi_handedness:
                for hand_lm, hand_info in zip(
                    results.multi_hand_landmarks,
                    results.multi_handedness
                ):
                    # MediaPipe labels "Left" / "Right" from the camera's POV.
                    # In mirror mode the label is flipped relative to the operator.
                    label = hand_info.classification[0].label
                    if self.mirror_mode:
                        side = 'left' if label == 'Right' else 'right'
                    else:
                        side = label.lower()

                    # Only accept the highest-confidence detection per side
                    if side not in landmarks_by_side:
                        landmarks_by_side[side] = hand_lm

                # Draw skeleton on preview
                if self.show_preview or self.pub_debug is not None:
                    for hand_lm in results.multi_hand_landmarks:
                        self.mp_draw.draw_landmarks(
                            frame, hand_lm,
                            self.mp_hands.HAND_CONNECTIONS,
                            self.mp_draw_styles.get_default_hand_landmarks_style(),
                            self.mp_draw_styles.get_default_hand_connections_style(),
                        )

            with self._lock:
                self._last_landmarks = landmarks_by_side
                self._last_frame = frame if (self.show_preview or self.pub_debug is not None) else None

            if self.show_preview and self._last_frame is not None:
                self._draw_overlay(frame, landmarks_by_side)
                cv2.imshow('Teleop Preview — press Q to quit', frame)
                if cv2.waitKey(1) & 0xFF == ord('q'):
                    self._running = False

    # ─────────────────────────────────────────────────────────────────────────
    # Overlay: workspace position & gripper state HUD
    # ─────────────────────────────────────────────────────────────────────────

    def _draw_overlay(self, frame, landmarks_by_side):
        h, w = frame.shape[:2]
        for side, lm in landmarks_by_side.items():
            pts = lm.landmark
            cx = int(pts[WRIST].x * w)
            cy = int(pts[WRIST].y * h)
            col = (50, 200, 50) if side == 'left' else (50, 50, 200)
            pinch = self._pinch_distance(pts)
            grip_state = 'CLOSED' if (
                self.gripper_left.is_closed if side == 'left'
                else self.gripper_right.is_closed
            ) else 'OPEN'
            cv2.putText(frame, f'{side.upper()} — grip:{grip_state}  pinch:{pinch:.2f}',
                        (cx - 80, cy - 15), cv2.FONT_HERSHEY_SIMPLEX, 0.45, col, 1,
                        cv2.LINE_AA)

        cv2.putText(frame, 'TELEOP ACTIVE', (10, 22),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 200, 200), 2, cv2.LINE_AA)

    # ─────────────────────────────────────────────────────────────────────────
    # Publish timer callback
    # ─────────────────────────────────────────────────────────────────────────

    def _timer_callback(self):
        with self._lock:
            landmarks = dict(self._last_landmarks)

        stamp = self.get_clock().now().to_msg()

        for side in ('left', 'right'):
            if side in landmarks:
                pose, gripper_closed = self._landmarks_to_pose(side, landmarks[side])
            else:
                # No hand detected: hold current filtered position
                filt = self.filter_left if side == 'left' else self.filter_right
                if filt.value is None:
                    continue
                v = filt.value
                pose = self._make_pose(v[0], v[1], v[2], v[3])
                gripper_closed = (
                    self.gripper_left.is_closed if side == 'left'
                    else self.gripper_right.is_closed
                )

            ps = PoseStamped()
            ps.header = Header(stamp=stamp, frame_id=self.frame_id)
            ps.pose   = pose

            grip_msg = Bool(data=gripper_closed)

            if side == 'left':
                self.pub_left_ee.publish(ps)
                self.pub_left_grip.publish(grip_msg)
            else:
                self.pub_right_ee.publish(ps)
                self.pub_right_grip.publish(grip_msg)

        # Debug image
        if self.pub_debug is not None and CV_BRIDGE_AVAILABLE:
            with self._lock:
                frame = getattr(self, '_last_frame', None)
            if frame is not None:
                msg = self.bridge.cv2_to_imgmsg(frame, 'bgr8')
                msg.header.stamp = stamp
                self.pub_debug.publish(msg)

    # ─────────────────────────────────────────────────────────────────────────
    # Landmark → filtered EE pose
    # ─────────────────────────────────────────────────────────────────────────

    def _landmarks_to_pose(
        self, side: str, hand_lm
    ) -> Tuple[Pose, bool]:
        pts = hand_lm.landmark

        # Raw hand coordinates (normalised [0,1])
        hx = pts[WRIST].x
        hy = pts[WRIST].y

        # Map to robot workspace
        raw_y = hand_x_to_ee_y(hx)
        raw_z = hand_y_to_ee_z(hy)

        # Wrist rotation from thumb angle
        raw_yaw = self._compute_wrist_yaw(pts)

        raw = np.array([WS_X_FIXED, raw_y, raw_z, raw_yaw])

        # Apply EMA + velocity clamp
        filt = self.filter_left if side == 'left' else self.filter_right
        filtered = filt.update(raw)

        fx, fy, fz, fyaw = filtered

        # Clamp to workspace
        fy   = float(np.clip(fy,   WS_Y_MIN,       WS_Y_MAX))
        fz   = float(np.clip(fz,   WS_Z_MIN,       WS_Z_MAX))
        fyaw = float(np.clip(fyaw, -WS_YAW_RANGE/2, WS_YAW_RANGE/2))

        pose = self._make_pose(fx, fy, fz, fyaw)

        # Gripper control
        pinch = self._pinch_distance(pts)
        gripper = self.gripper_left if side == 'left' else self.gripper_right
        closed  = gripper.update(pinch)

        return pose, closed

    def _compute_wrist_yaw(self, pts) -> float:
        """
        Estimate wrist yaw from the angle of the thumb metacarpal (CMC→MCP).
        Returns value in [-pi/2, +pi/2].
        """
        dx = pts[THUMB_MCP].x - pts[THUMB_CMC].x
        dy = pts[THUMB_MCP].y - pts[THUMB_CMC].y
        angle = math.atan2(dy, dx)
        # Normalise to [-pi/2, pi/2]
        angle = max(-math.pi / 2, min(math.pi / 2, angle))
        return angle

    def _pinch_distance(self, pts) -> float:
        """Normalised Euclidean distance between thumb tip and index tip."""
        tx, ty = pts[THUMB_TIP].x, pts[THUMB_TIP].y
        ix, iy = pts[INDEX_TIP].x, pts[INDEX_TIP].y
        return math.hypot(tx - ix, ty - iy)

    @staticmethod
    def _make_pose(x: float, y: float, z: float, yaw: float) -> Pose:
        """Build a Pose message from XYZ position and Z-axis rotation (yaw)."""
        p = Pose()
        p.position.x = float(x)
        p.position.y = float(y)
        p.position.z = float(z)
        # Quaternion from yaw only: q = [0, 0, sin(yaw/2), cos(yaw/2)]
        half_yaw = yaw / 2.0
        p.orientation.x = 0.0
        p.orientation.y = 0.0
        p.orientation.z = math.sin(half_yaw)
        p.orientation.w = math.cos(half_yaw)
        return p

    # ─────────────────────────────────────────────────────────────────────────
    # Cleanup
    # ─────────────────────────────────────────────────────────────────────────

    def destroy_node(self):
        self._running = False
        self._cam_thread.join(timeout=2.0)
        self.cap.release()
        self.hands.close()
        cv2.destroyAllWindows()
        super().destroy_node()


# ─────────────────────────────────────────────────────────────────────────────

def main(args=None):
    rclpy.init(args=args)
    node = TeleopNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
